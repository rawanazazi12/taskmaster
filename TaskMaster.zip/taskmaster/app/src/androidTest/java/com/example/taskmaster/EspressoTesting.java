package com.example.taskmaster;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.core.app.ActivityScenario;
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4ClassRunner.class)
public class EspressoTesting {

//    @Rule
//    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(MainActivity.class);
    @Test
    public void testAddTask(){
        try (ActivityScenario<MainActivity> ignored= ActivityScenario.launch(MainActivity.class)){
            onView(withId(R.id.add_task_btn)).perform(click());
            onView(withId(R.id.add_task_header)).check(matches(withText("Add Task")));
        }

    }

    @Test
    public void assertTextChanged() {
        try (ActivityScenario<MainActivity> ignored= ActivityScenario.launch(MainActivity.class)) {
            onView(withId(R.id.settings_btn)).perform(click());
            onView(withId(R.id.username)).perform(typeText("Rawan"), closeSoftKeyboard());
            onView(withId(R.id.save_btn)).perform(click());
            onView(withId(R.id.userTasks)).check(matches(withText("Rawan's Tasks")));
        }
    }
}
